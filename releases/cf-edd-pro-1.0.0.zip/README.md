
# Caldera Forms EDD (Prov Version)
Sell [Easy Digital Downloads](https://easydigitaldownloads.com/) products with [Caldera Forms](https://CalderaForms.com). Has many other useful features.  [Learn more on our website](https://calderaforms.com/downloads/easy-digital-downloads-for-caldera-forms-pro)

Requires Caldera Forms 1.4.7 or later and Easy Digital Downloads 2.5 or later.


### PUBLIC REPO FOR A PAID PRODUCT
We are experimenting with using public git repos for commercial products. Support will only be provided via our [support system](https://calderaforms.com/support/) which requires a valid license. If you are using this plugin please choose to purchase a license to receive support, support our work and 
enable live updates.


[Feel free to report bug here](https://github.com/CalderaWP/cf-edd-pro/issues) -- pull requests are accepted.


### License & Copyright
* Copyright 2016 Josh Pollock & CalderaWP LLC.
