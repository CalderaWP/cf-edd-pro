<?php
/**
 * Setup EDD auto-populate option in admin
 *
 * @package Caldera_Forms
 * @author    Josh Pollock <Josh@CalderaWP.com>
 * @license   GPL-2.0+
 * @link
 * @copyright 2016 CalderaWP LLC
 */

namespace calderawp\cfedd\cf\populate;


class admin extends  \calderawp\cfeddfields\fields\populate\admin {

	/** Extending empty and leaving this as a stub for future pro only options */

}