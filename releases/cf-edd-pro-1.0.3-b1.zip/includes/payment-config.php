<?php
echo Caldera_Forms_Processor_UI::config_fields( \calderawp\cfedd\cf\init\payment::processor_fields() );