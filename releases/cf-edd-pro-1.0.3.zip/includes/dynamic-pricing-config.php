<?php
/**
 * Configuration template for dynamic pricing processor
 *
 * @package Caldera_Forms
 * @author    Josh Pollock <Josh@CalderaWP.com>
 * @license   GPL-2.0+
 * @link
 * @copyright 2016 CalderaWP LLC
 */
echo Caldera_Forms_Processor_UI::config_fields( \calderawp\cfedd\cf\init\pricing::processor_fields() );
